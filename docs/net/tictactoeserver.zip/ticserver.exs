#Tic Tac Toe server
#Rich A Marino Tic Tac Toe Server v.01
#based on https://rm.vg/webserverv01.exs
#based on https://gist.github.com/javierg/0ae30e7ea47d3d18c39a

#issues:
#web server ignores mime types
#tic server does not implement PUT according to W3 spec. Does not send
# 501s.  This is not a functional deficiency. 

#other notes:
#the game could be made two player if the html UI is altered to allow
#opening a game and playing as x. Additionally, some minor changes to
#the main routine would be required to not assume that waiting = it's o's
#turn. You'd need to switch the game state to xturn and wait for x to play

defmodule TicServer do
  def getConf( conf_name ) do
    Agent.get(:conf_store, fn map-> Map.get( map, conf_name) end)
  end
  
  def setConf( conf_name, new_value) do
    Agent.update(:conf_store, fn map-> Map.put( map, conf_name, new_value) end )
  end
  
  def getTic( tic_name ) do
    Agent.get(:tic_store, fn map-> Map.get( map, tic_name) end)
  end
  
  def setTic( tic_name, new_value) do
    Agent.update(:tic_store, fn map-> Map.put( map, tic_name, new_value) end )
  end
  
  def start_server(port) do
    #Set up the server
    #Set up an agent to hold a KV pair of config data.
    {:ok, apid} = Agent.start_link( fn -> %{} end )
    Process.register(apid, :conf_store)
    setConf( "base_dir", System.cwd())
    setConf( "new_game_id", 101)

    #Set up an agent to hold the tic tac toe games.
    {:ok, tpid} = Agent.start_link( fn -> %{} end )
    Process.register(tpid, :tic_store)

    pid = spawn fn ->
      {:ok, listen} = :gen_tcp.listen(port, [:binary, {:active, false}])
      spawn fn -> acceptor(listen) end
      :timer.sleep(:infinity)
    end
    {:ok, pid}
  end

  #socket acceptor
  def acceptor(listen_socket) do
    {:ok, socket} = :gen_tcp.accept(listen_socket)
    spawn fn -> acceptor(listen_socket) end
    handle(socket)
  end

  #returns 80 if i > 3, or 90 if not.
  def test_function(i) do
    if(i > 3 ) do
      80
    else
      90
    end
  end

  #respond to an http request.
  #socket is the socket on which to respond.
  #http message is the HTTP message (e.g. "200 OK" or "404 Not Found")
  #Content is the file to be sent.
  def http_respond(socket, httpmessage, content) do
    :gen_tcp.send( socket, "HTTP/1.1 " <> httpmessage <> "\r\nServer: trump/0.1\r\nContent-Length:" 
      <> Integer.to_string( byte_size(content) )
      <> "\r\nConnection:close\r\nContent-Type: text/html\r\n\r\n" <> content )
  end

  #send the correct content based on error code.
  #404, xtra should be filename
  #400, xtra is appended after the description.
  def http_send_page(socket, http_code, xtra) do
    if http_code == 404 do
      http_respond( socket, "404 Not Found", 
        "<html><body>File '" <> xtra <> "' not found.</body></html>" )
    end
    if http_code == 400 do
      http_respond( socket, "400 Bad Request", 
        "<html><body><h1>400 Bad Request</h1>Your browser sent a request that the server could not understand." 
        <> xtra 
        <> "</body></html>" )
    end
  end

  #Used for http_get_file_handle
  #concat list of strings onto string
  defp concat_dir(string, list) do
    string = string <> "<a href='" <> hd(list) <> "'>" <> hd(list) <> "</a><br/>"

    IO.inspect( list )
    if ( length( list ) > 1 ) do
      concat_dir(string, tl(list) )
    else
      IO.inspect( string )
    end
  end

  #Handle a normal http get for a file
  #for Tic Tac Toe, this is used to serve index.html.
  defp http_get_file_handle(socket, filename) do    
    base_dir = getConf( "base_dir")
    fpath = base_dir <> filename
    if( File.exists?( fpath ) ) do
      if( File.dir?( fpath ) ) do
        #see if there is index.html
        if( File.exists?( fpath <> "/index.html" ) ) do
          case File.read( fpath <> "/index.html" ) do
            {:ok, body } -> http_respond(socket, "200 OK", body )
            {:error, nil } -> #reason was changed to nil cause unused
              http_send_page( socket, 404, filename)
          end
        else
          #!!! For security reasons, directory listing is disabled.
          #files = elem( File.ls( fpath ), 1)
          #content = "<html><body><h1>dir list of '" 
          #            <> filename 
          #            <> "'</h1><br/>"
          #content = concat_dir( content, files )
          #content = content <> "</body></html>"
          #http_respond(socket, "200 OK", content)
          http_send_page( socket, 404, "")
        end
      else
        case File.read( fpath ) do
          {:ok, body } -> http_respond(socket, "200 OK", body )
          {:error, nil } -> 
              http_send_page( socket, 404, filename)
        end
      end  
    else
      http_send_page( socket, 404, filename)
    end

  end #http_get_file_handle

  
  #Takes a game board, returns true if the space is not occupied, false
  #if the move cannot be performed.
  def is_move_valid( gb, x, y) do
    if elem( elem(gb, y), x) == "-" do
      true
    else
      false
    end
  end

  #Has x move to a random position.  Returns a game board.
  def do_computer_move( gb ) do
    IO.puts( "computer moves")
    clist = []
    clist = clist ++ if elem( elem(gb, 0), 0) == "-" do [{0,0}] else [] end
    clist = clist ++ if elem( elem(gb, 0), 1) == "-" do [{1,0}] else [] end
    clist = clist ++ if elem( elem(gb, 0), 2) == "-" do [{2,0}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 0) == "-" do [{0,1}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 1) == "-" do [{1,1}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 2) == "-" do [{2,1}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 0) == "-" do [{0,2}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 1) == "-" do [{1,2}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 2) == "-" do [{2,2}] else [] end

    IO.inspect( clist )
    co = Enum.random(clist)
    IO.inspect( co )
    gb = put_elem( gb, elem( co, 1), put_elem( elem(gb, elem( co, 1)), elem( co, 0), "x"))
    IO.inspect( gb )
    gb
  end

  #Check to see if someone has won the game.
  #Returns "-" if no one won, or "x" or "o" as appropriate. If there is a draw
  #returns "draw".
  #Note that the method simply checks that the values are equal, 
  #so symbols other than "x" or "o" would work.
  #Calls is_draw if no one is a winner and returns "draw" if there is a draw.
  def get_winner( gb ) do
    IO.puts("Calling get_winner")
    IO.inspect(gb)
    res = "-"
    #row
    if res == "-" and elem( elem(gb, 0), 0) == elem( elem(gb, 1), 0) and elem( elem(gb, 1), 0) == elem( elem(gb, 2), 0) do
            IO.puts("1")
            res = elem( elem(gb, 0), 0)
          else "-" end
    if res == "-" and elem( elem(gb, 0), 1) == elem( elem(gb, 1), 1) and elem( elem(gb, 1), 1) == elem( elem(gb, 2), 1) do
            IO.puts("2")
            res = elem( elem(gb, 0), 1)
          else "-" end
    if res == "-" and elem( elem(gb, 0), 2) == elem( elem(gb, 1), 2) and elem( elem(gb, 1), 2) == elem( elem(gb, 2), 2) do
            IO.puts("3")
            res = elem( elem(gb, 0), 2) 
          else "-" end
    #col
    if res == "-" and elem( elem(gb, 0), 0) == elem( elem(gb, 0), 1) and elem( elem(gb, 0), 1) == elem( elem(gb, 0), 2) do
            IO.puts("5")
            res = elem( elem(gb, 0), 0) 
          else "-" end
    if res == "-" and elem( elem(gb, 1), 0) == elem( elem(gb, 1), 1) and elem( elem(gb, 1), 1) == elem( elem(gb, 1), 2) do 
            IO.puts("6")
            res = elem( elem(gb, 1), 0) 
          else "-" end
    if res == "-" and elem( elem(gb, 2), 0) == elem( elem(gb, 2), 1) and elem( elem(gb, 2), 1) == elem( elem(gb, 2), 2) do
            IO.puts("7")
            res = elem( elem(gb, 2), 0) 
          else "-" end
    #diagonal
    if res == "-" and elem( elem(gb, 0), 0) == elem( elem(gb, 1), 1) and elem( elem(gb, 1), 1) == elem( elem(gb, 2), 2) do
            IO.puts("8")
            res = elem( elem(gb, 1), 1)
          else "-" end
    if res == "-" and elem( elem(gb, 2), 0) == elem( elem(gb, 1), 1) and elem( elem(gb, 1), 1) == elem( elem(gb, 0), 2) do
            IO.puts("9")
            res = elem( elem(gb, 0), 2) 
          else "-" end
    IO.inspect( res)
    if res == "-" and is_draw( gb ) do
      res = "draw"
    end
    res
  end

  #Returns true if no moves are possible
  #False if moves can still happen.
  def is_draw( gb ) do
    clist = []
    clist = clist ++ if elem( elem(gb, 0), 0) == "-" do [{0,0}] else [] end
    clist = clist ++ if elem( elem(gb, 0), 1) == "-" do [{1,0}] else [] end
    clist = clist ++ if elem( elem(gb, 0), 2) == "-" do [{2,0}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 0) == "-" do [{0,1}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 1) == "-" do [{1,1}] else [] end
    clist = clist ++ if elem( elem(gb, 1), 2) == "-" do [{2,1}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 0) == "-" do [{0,2}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 1) == "-" do [{1,2}] else [] end
    clist = clist ++ if elem( elem(gb, 2), 2) == "-" do [{2,2}] else [] end
    if length( clist ) == 0 do
      true
    else
      false
    end
  end

  #main socket handler
  def handle(socket) do
    :inet.setopts(socket, [{:active, :once}])
    receive do
      {:tcp, socket , "quit" <> _} ->
        :gen_tcp.close(socket)
      {:tcp, socket, msg} ->
        pattern = :binary.compile_pattern(["\r\n", "\n"])
        msglines = String.split(msg, pattern)
        httpcmd = String.split( hd(msglines), " ")
        if length(httpcmd) < 3 do
          IO.puts("invalid http cmd")
          IO.inspect( httpcmd )
          :gen_tcp.send(socket, "Invalid CMD" <> msg);
        else
          IO.puts("check http cmd")
          IO.inspect( httpcmd )
          httpverb = hd(httpcmd)
          httpfile = tl(httpcmd)
          httpver = hd( tl(httpfile) )
          httpfile = hd(httpfile)
          IO.puts( "verb = " <> httpverb)
          IO.puts(" file = " <> httpfile)
          IO.puts(" ver = " <> httpver )
          if httpverb == "GET" do
            if String.starts_with?( httpfile, "/game/" ) do
              strparts = String.split( httpfile, "/")
              if( length( strparts ) >= 3 ) do
                IO.inspect( strparts )
                gameidstr = hd( tl( tl( strparts) ) )
                gameid = String.to_integer( gameidstr )
                
                #get the game
                gamedata = getTic(gameid)
                content = "{\"gameid\":" 
                  <> Integer.to_string( gameid )
                  <> ",\"state\":\""
                  <> hd(gamedata)
                  <> "\",\"board\":"
                board = hd(tl(gamedata))
                IO.inspect(board)

                IO.inspect( elem(board, 0) )
                content = content <> "[[\"" <> elem(elem(board,0),0) <> "\""
                content = content <> ",\"" <> elem(elem(board,0),1) <> "\""
                content = content <> ",\"" <> elem(elem(board,0),2) <> "\""
                content = content <> "],[\"" <> elem(elem(board,1),0) <> "\""
                content = content <> ",\"" <> elem(elem(board,1),1) <> "\""
                content = content <> ",\"" <> elem(elem(board,1),2) <> "\""
                content = content <> "],[\"" <> elem(elem(board,2),0) <> "\""
                content = content <> ",\"" <> elem(elem(board,2),1) <> "\""
                content = content <> ",\"" <> elem(elem(board,2),2) <> "\"]]"
                content = content <> "}"
                http_respond(socket, "200 OK", content)
              else
                http_respond(socket, "200 OK", "game not found.")
              end
              
            else
              http_get_file_handle( socket, httpfile )
            end
          end #httpverb = "GET"
          if httpverb == "POST" do
            #Create a new game and return the ID.
            gameid = getConf("new_game_id")
            setConf("new_game_id", gameid+1)
            setTic(gameid, ["oturn", {{"-", "-", "-"},{"-","-","-"},{"-","-","-"}}])
            http_respond( socket, "200 OK", 
              "{\"game_id\":" <> Integer.to_string(gameid)
              <> "}")
          end
          if httpverb == "PUT" do
            #Mark a move. If necessary, computer moves afterward.
            if String.starts_with?( httpfile, "/game/" ) do
              strparts = String.split( httpfile, "/")
              if( length( strparts ) >= 3 ) do
                #gameid = -1
                gameidstr = hd( tl( tl( strparts) ) )
                gameid = String.to_integer( gameidstr )
                gamedata = getTic(gameid)
                coordstring = List.last( msglines )
                coordstring_s = String.split( coordstring, "," )
                xs = hd( coordstring_s )
                ys = hd( tl( coordstring_s ) )
                x = String.to_integer( xs )
                y = String.to_integer( ys )
                gb = hd(tl( gamedata ))
                IO.inspect( gb )
                #check if the move is valid.

                  if is_move_valid( gb, x, y ) do
                    IO.puts("move valid")
                    gb = put_elem( gb, y, put_elem( elem(gb, y), x, "o"))
                    #check winner.
                    w = get_winner( gb )
                    IO.puts("get_winner1:")
                    IO.inspect( w )
                    if w != "-" do
                      #there is a winner
                      if w == "x" do
                        gamedata = List.replace_at( gamedata, 0, "xwon" )
                      end
                      if w == "o" do
                        gamedata = List.replace_at( gamedata, 0, "owon" )
                      end
                      if w == "draw" do
                        gamedata = List.replace_at( gamedata, 0, "draw" )
                      end #if w!= "-"
                    else
                      gb = do_computer_move( gb )
                      w = get_winner( gb )
                      IO.puts("get_winner2:")
                      IO.inspect( w )
                      if w != "-" do
                        #there is a winner
                        if w == "x" do
                          gamedata = List.replace_at( gamedata, 0, "xwon" )
                        end
                        if w == "o" do
                          gamedata = List.replace_at( gamedata, 0, "owon" )
                        end
                        if w == "draw" do
                          gamedata = List.replace_at( gamedata, 0, "draw" )
                        end
                      end #if w!= "-"
                    end #if is_move_valid
                    
                    #store the board back in the game.
                    gamedata = List.replace_at( gamedata, 1, gb)
                    #store the game
                    IO.inspect( gamedata )
                    setTic( gameid, gamedata )
                    #respond
                    http_respond(socket, "200 OK", "{\"result\":true}")                  
                  else
                    IO.puts("move invalid")
                    #respond
                    http_respond(socket, "200 OK", "{\"result\":false}")
                end
                IO.inspect( gb )
              end
            end
          end
          if httpverb == "DELETE" do
            #Mark the game as abandoned.
            IO.inspect( msglines )
            if String.starts_with?( httpfile, "/game/" ) do
              strparts = String.split( httpfile, "/")
              if( length( strparts ) >= 3 ) do
                gameidstr = hd( tl( tl( strparts) ) )
                gameid = String.to_integer( gameidstr )
                gamedata = getTic(gameid)
                gamedata = List.replace_at(gamedata,0,"ended")
                setTic(gameid, gamedata)
              end
            end
          end
        end
        handle(socket)
    end
  end
end

#start the server. The parameter is the port number.
TicServer.start_server(1200)

