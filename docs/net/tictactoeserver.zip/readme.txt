RAM Tic Tac Toe Server in Elixir

Deployment:
-to alter the port, edit the last line of ticserver.exs. Default is 1200.

Quick description:
This is a high performance tic tac toe server written in elixir. The server
includes an embedded web server, intended to serve index.html. The game
automatically implements sessions as each game is an independent entity.

To get started, run iex ticserver.exs.  By default, the server listens on 
port 1200.  Open a web browser to http://127.0.0.1:1200/ and click New Game
to play. (Client browser requires Javascript, any reasonably modern browser
should work).

Bonus points:
-Automatically implemented user sessions, due to the nature of implementing
  a server in Elixir. This results in massive parallelism available, and all
  games are atomic entities (unrelated to any other).



Issues:
-The server does not do anything to block cheating. Someone else can open a
game and play.  This could be added if needed, however it did not seem worth
the cost in this situation, as tic tac toe games don't last very long, nor
are highly valued.
-There is currently no way to play as X.

API Information:
The server will maintain the state of the game following proper HTTP verbs

GET /game/{id}
get the game board. return the ccurrent game board, and a status variable
status = {oturn, xturn, owon, xwon, draw, ended}
POST /game/
start a new game. response is the game id.  
PUT /game/{id}\r\n\r\n{xPlace,yPlace}
have the player place an O at the specified location.
if this is successful, the game is updated with a CPU move
internally, and the client should try to GET the game again.
returns 
	true if the move was valid
	false if it was invalid (something was there).
DELETE /game/{id} 
mark the game as ended.

Status codes for get
oturn - o's turn
xturn - x's turn (used for future two player functionality)
owon - game is over, o won the game.
xwon - game is over, x won the game.
draw - game is over, no one won.
ended - the user abandoned the game (client called DELETE /game/{id})

Board locations are 0 based:
0,0  1,0  2,0
0,1  1,1  2,1
0,2  1,2  2,2

