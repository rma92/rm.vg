<?php
$f = file_get_contents('dadeaddr2.csv');
$x = explode("\r\n", $f);
echo '$addr = array(';
foreach($x as $xx)
{
  echo $xx, ',';
}
echo (');');
?>
