<?php
$f = file_get_contents('dadeaddr2.csv');
$x = explode("\r\n", $f);
$f = null;
  $first = array('Aaron', 'John', 'James', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Charles', 'Joseph', 'Thomas', 'Christopher', 'Daniel', 'Paul', 'Mark', 'Donald', 'George', 'Kenneth', 'Steven', 'Edward', 'Brian', 'Ronald', 'Anthony', 'Kevin', 'Jason', 'Matthew', 'Juan', 'Athena', 'Mary', 'Patricia', 'Linda', 'Barbara', 'Elizabeth', 'Jennifer', 'Maria', 'Susan', 'Margaret', 'Dorothy', 'Lisa', 'Nancy', 'Karen', 'Betty', 'Helen', 'Sandra', 'Donna', 'Carol', 'Ruth', 'Sharon', 'Michelle', 'Laura', 'Sarah');

function make_name()
{
  global $first;
  $last = array('Rodriguez', 'Smith', 'Williams', 'Johnson', 'Jones', 'Brown', 'Davis', 'Miller', 'Wilson', 'Moore', 'Taylor', 'Anderson', 'Thomas', 'Jackson', 'White', 'Harris', 'Martin', 'Thompson', 'Garcia', 'Martinez', 'Robinson', 'Clark', 'Lewis', 'Lee', 'Walker', 'Hall', 'Allen', 'Young', 'Hernandez', 'King');
  return $first[array_rand($first)] . ' ' . $last[array_rand($last)];
}

function get_city()
{
  $cities = array( 'Orlando', 'Miami', 'Naples', 'Tampa', 'St Petersburg', 'Marco Island', 'Key West', 'Port St Lucie' );
  return $cities[array_rand($cities)];
}
function table_print($conn, $sql)
{
  $sf = $conn->prepare( $sql );
  $sf->execute();
  $arr1 = $sf->fetchAll(PDO::FETCH_ASSOC);
  //var_dump($arr1);
  echo '<table>', "\n  <tr>\n";
  foreach( array_keys($arr1[0]) as $kk )
  {
    echo '    <td>', $kk, "</td>\n";
  }
  echo "  </tr>\n";
  foreach( $arr1 as $kk )
  {
    echo "  <tr>\n";
    foreach( $kk as $kkk )
    {
      echo '    <td>', $kkk, "</td>\n";
    }
    echo "  </tr>\n";
  }
  echo '</table>';
}

//setup the database
$db = 'sqlite::memory:'; //'sqlite:file.db'
date_default_timezone_set('America/New_York');
$conn = new PDO( $db );
$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$conn->exec( 'CREATE TABLE Hotel (hotelNo INTEGER PRIMARY KEY, hotelName TEXT, city TEXT);' );
$conn->exec( 'CREATE TABLE Room (roomNo INTEGER, hotelNo INTEGER, type TEXT, price INTEGER);' );
$conn->exec( 'CREATE TABLE Booking (hotelNo INTEGER, guestNo INTEGER, dateFrom TEXT, dateTo TEXT, roomNo INTEGER);' );
$conn->exec( 'CREATE TABLE Guest (guestNo INTEGER PRIMARY KEY, guestName TEXT, guestAddress TEXT);' );

$numGuest = 12;
$numHotel = 30;
$roomMin = 20;
$roomMax = 40;
$numBookingsPerHotelRoom = 2;
$startDate = mktime(0, 0, 0, 1, 1, 2014);//the booking start date.
for($i = 0; $i < $numGuest; ++$i)
{
  $s1 = $conn->prepare( 'INSERT INTO Guest ( guestNo, guestName, guestAddress ) VALUES (:guestNo, :guestName, :guestAddress)' );
  $s1->bindValue( ':guestName', make_name() );
  $s1->bindValue( ':guestNo', $i);
  $s1->bindValue( ':guestAddress', $x[array_rand($x)] );
  $s1->execute();
  
  //echo make_name(), '<br/>';
}

for($i = 0; $i < $numHotel; ++$i)
{
  $s1 = $conn->prepare( 'INSERT INTO Hotel (hotelNo, hotelName, city) values (:ho, :name, :city) ' );
  $s1->bindValue( ':name', 'Hotel ' . $first[array_rand($first)] );
  $s1->bindValue( ':ho', $i );
  $s1->bindValue( ':city', get_city() );
  $s1->execute();
  $numRoom = rand($roomMin, $roomMax);
  for($j = 0; $j < $numRoom; ++$j)
  {
    $type_cnt = rand(5, 15);
    $s2 = $conn->prepare( 'INSERT INTO Room (roomNo, hotelNo, type, price) values (:roomNo, :ho, :type, :price); ' );
    $s2->bindValue( ':roomNo', $j );
    $s2->bindValue( ':ho', $i );
    $s2->bindValue( ':type', $type_cnt );
    $s2->bindValue( ':price', $type_cnt * 15 );
    $s2->execute();

    //book the room. Pick a random guest, select 86400 * 7 times the end date of his last reservation.
    for($k = 0; $k < $numBookingsPerHotelRoom; ++$k)
    {
      //randomly get a guest.
      $g = rand(0, $numGuest - 1);
      $s3 = $conn->prepare( 'SELECT MAX(dateTo) FROM Booking where guestNo = :gNo;' );
      $s3->bindValue( ':gNo', $g );
      $s3r = $s3->execute();
      $s3r = $s3->fetchAll();
      //now make the booking
      $bookBeginDate = $startDate; //FIX THIS TO THE ABOVE RESULT.
      if(isset($s3r[0][0]))
      {
        $bookBeginDate = $s3r[0][0];
      }
      $bookLength = 86400 * rand(1, 7);
      $s4 = $conn->prepare( 'INSERT INTO Booking (hotelNo, guestNo, dateFrom, dateTo, roomNo) values (:ho, :guestNo, :dateFrom, :dateTo, :roomTo)' );
      $s4->bindValue( ':ho', $i );
      $s4->bindValue( ':guestNo', $g);
      $s4->bindValue( ':dateFrom', $bookBeginDate );
      $s4->bindValue( ':dateTo', $bookBeginDate + $bookLength );
      $s4->bindValue( ':roomTo', $j );
      $s4->execute();
    }
  }
}

echo "<h2>Guest Table</h2>\r\n";
table_print( $conn, 'select * from Guest');
echo "<h2>Hotel Table</h2>\r\n";
table_print( $conn, 'select * from Hotel');
echo "<h2>Room Table</h2>\r\nFor readability purposes, hotelName and city are joined from the <b>Hotel</b> table.<br>";
table_print( $conn, 'select * from Room NATURAL JOIN Hotel');
echo "<h2>Booking Table</h2>\r\nFor readability purposes, hotel data is naturally joined.";
table_print( $conn, 'select hotelNo, guestNo, datetime(dateFrom, "unixepoch"), datetime(dateTo, "unixepoch"), roomNo, hotelName, city, ((dateTo-dateFrom)/86400) from Booking NATURAL JOIN Hotel');
$conn = NULL;
?>
